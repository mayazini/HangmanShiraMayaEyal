﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HangmanShiraMayaEyal
{
    public partial class HangmanGame : System.Web.UI.Page
    {
        public string randWord;

        public static string ShowWord(string randWord, string guessedletter)
        {
            string showWord = "";
            for (int j = 0; j < randWord.Length; j++)
            {
                //if(randWord[j] == guessedletter)
                //{
                //    showWord += guessedletter+" ";
                //}
                showWord += "_ ";
            }
            return showWord;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            string sql = "SELECT word FROM Words where CategoryId = "+ Request.QueryString["CategoryId"] + "";
            DataTable dt = SQLHelper.SelectData(sql);
            //int numOfWords = SQLHelper.SelectScalarToInt32("SELECT COUNT(word) FROM Words where CategoryId=" + Request.QueryString["CategoryId"] + "");
            int startNum = 0;
            int endNum = dt.Rows.Count;
            Random ram = new Random();
            int i = ram.Next(startNum, endNum);
            randWord = dt.Rows[i].Field<string>("word").ToString();
            
            if(Request["btnsubmit"] != null)
            {
                if(Request["guessedLetter"].ToString() !="")
                    randWord = ShowWord(randWord, Request["guessedLetter"].ToString());
                randWord = ShowWord(randWord, " ");
            }
            else
            {
                randWord = ShowWord(randWord, " ");
            }
        }
    }
}